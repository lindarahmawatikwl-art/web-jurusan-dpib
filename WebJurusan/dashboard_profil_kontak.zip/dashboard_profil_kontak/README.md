# Dashboard Kelola Profil & Kontak — DPIB SMKN 1 Kawali

## Isi paket
- `admin/admin.php`: dashboard utama dengan tautan menu Kontak yang diarahkan ke halaman pengelolaan.
- `admin/profil.php`: mengelola Visi & Misi, banner Struktur Organisasi, banner Himpunan Siswa, serta menambah/menghapus anggota dan mengatur urutannya.
- `admin/kontak_kelola.php`: mengelola peta, alamat, telepon, email, Instagram, TikTok, dan WhatsApp.
- `database.sql`: tabel dan data awal.

## Cara pemasangan
1. Cadangkan database dan file website terlebih dahulu.
2. Buka phpMyAdmin, pilih database yang dipakai oleh `koneksi.php`, lalu jalankan `database.sql`.
3. Salin `admin/admin.php`, `admin/profil.php`, dan `admin/kontak_kelola.php` ke folder admin yang sama dengan `koneksi.php`, `login.php`, `logout.php`, dan dashboard admin. Jika folder admin Anda berbeda, sesuaikan path `require_once "koneksi.php"` dan tautan menu.
4. Pastikan folder `img/uploads` dapat ditulis oleh PHP agar unggah banner bekerja.
5. Dashboard `admin.php` dalam paket ini sudah mengarahkan menu Kontak ke `kontak_kelola.php`. Gunakan file tersebut untuk menggantikan dashboard admin lama setelah membuat cadangan. Menu Profil diarahkan ke `profil.php`. Jangan menimpa halaman publik `kontak.php`.
6. Kedua halaman admin memeriksa `$_SESSION['admin']`, mengikuti pola login yang ada pada dashboard Anda.

## Catatan integrasi halaman publik
Halaman publik `Visi_misi.php`, `SO.php`, dan `kontak.php` yang Anda kirim saat ini masih menampilkan teks/gambar/tautan yang ditulis langsung di file. Dashboard ini menyimpan perubahan ke tabel database, tetapi supaya perubahan admin otomatis muncul pada halaman publik, bagian tampilan publik perlu dihubungkan ke tabel `profil_konten`, `profil_anggota`, dan `kontak_website`. Kolom `foto` anggota disiapkan, tetapi unggah foto anggota belum disertakan dalam versi ini. Struktur ini tidak mengubah tabel `artikel` atau `galeri` yang sudah ada.
