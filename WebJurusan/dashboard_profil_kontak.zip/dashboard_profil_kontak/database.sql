-- Jalankan di database website yang sudah digunakan oleh koneksi.php.
CREATE TABLE IF NOT EXISTS profil_konten (
  bagian VARCHAR(30) NOT NULL PRIMARY KEY,
  visi TEXT NULL,
  misi TEXT NULL,
  banner VARCHAR(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS profil_anggota (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  bagian ENUM('struktur','himpunan') NOT NULL,
  nama VARCHAR(120) NOT NULL,
  jabatan VARCHAR(120) NOT NULL,
  foto VARCHAR(255) NOT NULL DEFAULT '',
  urutan INT NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_bagian_urutan (bagian, urutan)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS kontak_website (
  id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
  alamat TEXT NOT NULL,
  telepon VARCHAR(50) NOT NULL,
  email VARCHAR(190) NOT NULL,
  peta_embed TEXT NOT NULL,
  instagram VARCHAR(255) NOT NULL DEFAULT '',
  tiktok VARCHAR(255) NOT NULL DEFAULT '',
  whatsapp VARCHAR(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO kontak_website (id, alamat, telepon, email, peta_embed, instagram, tiktok, whatsapp)
VALUES (1, 'Jl. Talagasari, No. 35, Kawalimukti, Kawali, Kabupaten Ciamis, Jawa Barat 46253',
'082 9517 4679', 'info@smkn1kawali.sch.id',
'https://www.google.com/maps?q=SMK%20Negeri%201%20Kawali&output=embed',
'https://www.instagram.com/', 'https://www.tiktok.com/', 'https://www.whatsapp.com/')
ON DUPLICATE KEY UPDATE id=VALUES(id);

INSERT INTO profil_konten (bagian, visi, misi, banner) VALUES
('visi_misi','Mewujudkan ekosistem pembelajaran berbasis industri untuk menghasilkan lulusan yang kompeten, profesional, berportofolio, dan siap diserap dunia kerja.','Meningkatkan kompetensi & profesionalisme\nMenghasilkan portofolio berstandar industri\nMenciptakan lulusan siap kerja & berwirausaha\nMemperkuat kemitraan strategis dengan DUDI',''),
('struktur','','',''),
('himpunan','','','')
ON DUPLICATE KEY UPDATE bagian=VALUES(bagian);
